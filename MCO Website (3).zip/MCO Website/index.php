<?php

	session_start();				

		//Constant
	define('CHEMIN_VUES','views/');
	define('CHEMIN_CONTROLEURS','controllers/');
    define('DEV1','DE VISCH Manon');
	define('DEV2','JEANJEAN Adrien');
	define('DATEDUJOUR',date("j/m/Y"));
	define('SESSION_ID',session_id());
	define('VILLE','Namur');
	define('GROUPE','pantheres rouges');

	function chargerClasse($classe) {
		require_once 'models/' . $classe . '.class.php';
	}
	spl_autoload_register('chargerClasse');


	$db=Db::getInstance();

	if (empty($_SESSION['authentifie'])){
		$actionlogin = 'Anonyme';
		$libellelogin='Anonyme';
	} else {
		$actionlogin='user';
		$libellelogin='user';
	}

	require_once(CHEMIN_VUES.'header.php');


	$action = (isset($_GET['action'])) ? $_GET['action'] : 'default';

	switch($action) {
		case 'apropos':
			require_once(CHEMIN_CONTROLEURS.'aProposController.php');
			$controller = new AProposController();
			break;
		case 'contact':
			require_once(CHEMIN_CONTROLEURS.'contactController.php');
			$controller = new ContactController($db);
			break;
		case 'coach':
			require_once(CHEMIN_CONTROLEURS . 'coachController.php');
			$controller = new CoachController($db);
			break;
		case 'contact':
			require_once(CHEMIN_CONTROLEURS.'contactController.php');
			$controller = new ContactController();
			break;
		case 'creationEntrainement':
			require_once(CHEMIN_CONTROLEURS . 'creationEntrainementController.php');
			$controller = new CreationEntrainementController();
			break;
		case 'creationEvenement':
			require_once(CHEMIN_CONTROLEURS . 'creationEvenementController.php');
			$controller = new CreationEvenementController($db);
			break;
		case 'inscription':
			require_once(CHEMIN_CONTROLEURS . 'inscriptionController.php');
			$controller = new InscriptionController($db);
			break;
		case 'login' :
						require_once(CHEMIN_CONTROLEURS . 'loginController.php');
						$controller = new LoginController($db);
						break;
		case 'membre':
				    require_once(CHEMIN_CONTROLEURS . 'membreController.php');
				    $controller = new MembreController($db);
				    break;
		case 'membreResponsable':
						require_once(CHEMIN_CONTROLEURS . 'membreResponsableController.php');
						$controller = new MembreResponsableController($db);
						break;
		case 'modification':
						require_once(CHEMIN_CONTROLEURS . 'modificationController.php');
						$controller = new ModificationController($db);
						break;
		case 'valider' :
						require_once(CHEMIN_CONTROLEURS . 'validerController.php');
						$controller = new ValiderController($db);
						break;
		case 'AccueilUser' :
						require_once(CHEMIN_CONTROLEURS . 'accueilUserController.php');
						$controller = new accueilUserController();
						break;
		default:
			require_once(CHEMIN_CONTROLEURS.'AccueilController.php');
			$controller = new AccueilController();
			break;
	}

	$controller->run();

	require_once(CHEMIN_VUES . 'footer.php');

?>
