<?php
class MembreController{

	public function __construct() {

	}

	public function run(){
		
		$tab_users='';
			$tab_users=Db::getInstance()->select_users();

		require_once(CHEMIN_VUES . 'membre.php');
	}
}
?>
