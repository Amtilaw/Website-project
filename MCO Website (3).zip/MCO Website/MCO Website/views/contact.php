<body>
<h1>Contact</h1>

<p> <bold>Joindre le club : </bold><br>
    0473453498 <br>
    Rue des Carmes <br>
    5000 Namur <br> <br>

    <bold>Questions ou commentaire?</bold><br>
    Votre adresse email : <input type="text" name="email" /> <br>
    <textarea rows="3" name="message">Entrez votre message ici</textarea>
    <br>
    <input type="submit" value="envoyer"/>




</body>
