<body>
<div id="notification"><?php echo $notification; ?></div>
			<div class="formulaire">
				
<form action="?action=inscription" method="post">
    <p class="h4 text-center mb-4">Subscribe</p>

    <!-- Material input text -->
    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="name">
        <label for="materialFormSubscriptionNameEx">name*</label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="firstname">
        <label for="materialFormSubscriptionNameEx">Firstname*</label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="phone">
        <label for="materialFormSubscriptionNameEx">phone*</label>
    </div>

    <!-- Material input email -->
    <div class="md-form">
        <i class="fa fa-envelope prefix grey-text"></i>
        <input type="email" id="materialFormSubscriptionEmailEx" class="form-control" name="email">>
        <label for="materialFormSubscriptionEmailEx">email*</label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="adress">>
        <label for="materialFormSubscriptionNameEx">adress*</label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="iban">
        <label for="materialFormSubscriptionNameEx">Iban*</label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="photo">
        <label for="materialFormSubscriptionNameEx">photo</label>
    </div>

    <div class="md-form">
                <i class="fa fa-lock prefix grey-text"></i>
                <input type="password" id="materialFormCardPasswordEx" class="form-control" name="password">
                <label for="materialFormCardPasswordEx" class="font-weight-light">password*</label>
            </div>
    <div class="text-center mt-4">
        <button class="btn btn-outline-info" type="submit">Send<i class="fa fa-paper-plane-o ml-2"></i></button>
    </div>
</form>
<!-- Material form subscription -->
                      
			</div>


</body>