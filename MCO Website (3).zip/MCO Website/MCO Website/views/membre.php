<section id="contenu">
  <table id="tableBalises">
    <thead>
      <tr>
        <th>num</th>
        <th>name</th>
        <th>firstname</th>
        <th>email</th>
        <th>password</th>
        <th>phone</th>
        <th>iban</th>
        <th>role</th>
      </tr>
    </thead>
    <tbody>
    <?php for ($i=0;$i<count($tab_users);$i++) { ?>
      <tr>
      <td><span class="html"><?php echo $tab_users[$i]->num() ?></span></td>
      <td><?php echo $tab_users[$i]->name() ?></td>
      <td><?php echo $tab_users[$i]->firstname() ?></td>
      <td><?php echo $tab_users[$i]->email() ?></td>
      <td><?php echo $tab_users[$i]->password() ?></td>
      <td><?php echo $tab_users[$i]->phone() ?></td>
      <td><?php echo $tab_users[$i]->iban() ?></td>
      <td><?php echo $tab_users[$i]->role() ?></td>

      </tr>
    <?php } ?>
    </tbody>
  </table>
<!-->
  <div class="formulaire">
    <form action="index.php?action=livres" method="post">
    <p>Titre du livre :	<input type="text" name="titre" /></p>
    <p>Auteur : <input type="text" name="auteur" /></p>
    <p><input type="submit" name="form_ajout" value="Ajouter"></p>
    </form>
  </div>
  <div id="notification"><?php// echo $notification; ?></div>
  <!-->
</section>
