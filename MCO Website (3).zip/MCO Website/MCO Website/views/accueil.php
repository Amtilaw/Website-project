<body>
    <h1>ACCUEIL</h1>

    <p id="textAccueil">Bienvenue sur le site officiel des coureurs du groupe des <br>
        panthères rouges de la ville de Namur en Belgique. <br>
        Ce site est réservé  aux membres du club, il permet la <br>
      gestion de ses membres (cotisations),<br>
      des évènements, ainsi que des plans d'entrainements.<br>

    Attention !  Pour s'inscrire, il faut  être membre.<br>
    aL'inscription devra  être valider par un responsable</p>


</body>
