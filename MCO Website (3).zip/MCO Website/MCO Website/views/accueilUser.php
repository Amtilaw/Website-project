<body>


<p>Bonjour <?php echo $_SESSION['login']?>
</p>



</body>