<?php
class Db
{
    private static $instance = null;
    private $_db;

    private function __construct()
    {
        try {
            $this->_db = new PDO('mysql:host=localhost;dbname=site;charset=utf8', 'root', '');
            $this->_db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			$this->_db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);
        }
		catch (PDOException $e) {
		    die('Erreur de connexion à la base de données : '.$e->getMessage());
        }
    }

	# Pattern Singleton
    public static function getInstance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new Db();
        }
        return self::$instance;
    }

	public function select_users($keyword='') {
		# Définition du query
		if ($keyword != '') {
			$keyword = str_replace("'", "\'", $keyword);
			$keyword = str_replace("%", "\%", $keyword);
			$query = "SELECT * FROM users WHERE name LIKE '%" . $keyword . "%' collate utf8_bin ORDER BY no ASC ";
		} else {
			$query = 'SELECT * FROM users ORDER BY name ASC';
		}
		$result = $this->_db->query($query);

		# Parcours de l'ensemble des résultats et construction d'un tableau d'objet(s) de la classe Livre
		$tableau = array();
		if ($result->rowcount()!=0) {
			while ($row = $result->fetch()) {
				$tableau[] = new User($row->num,$row->firstname,$row->adress, $row->email, $row->password, $row->iban, $row->role);
			}
		}
		return $tableau;
	}

	public function insert_user($name, $firstname, $adress, $email, $password, $iban) {
		$query = 'INSERT INTO users (name, firstname, adress, email, password, iban)
				  values (:name, :firstname, :adress, :email, :password, :iban )';
		$qp = $this->_db->prepare($query);

	$qp->bindValue(':name',$name);
    $qp->bindValue(':firstname',$firstname);
    $qp->bindValue(':adress',$adress);
    $qp->bindValue(':email',$email);
    $qp->bindValue(':password',$password);
    $qp->bindValue(':iban',$iban);
    		$qp->execute();

	}
}
