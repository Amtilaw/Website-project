<?php
class User{
	private $_num;
	private $_name;
	private $_firstname;
  private $_adress;
  private $_email;
  private $_password;
  private $_phone;
  private $_iban;
  private $_role;

	public function __construct($num, $name, $firstname, $adress, $email, $password, $iban, $role){
		this->_num = $num;
    this->_name = $name;
    this->_firstname = $firstname;
    this->_adress = $adress;
    this->_email = $email;
    this->_password = $password;
    this->_iban = $iban;
    this->_role = $role
	}

	public function no(){

	}

	public function titre(){
	}

	public function auteur(){
	}
}
?>
