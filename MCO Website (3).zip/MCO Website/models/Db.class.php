<?php
class Db
{
    private static $instance = null;
    private $_db;

    private function __construct()
    {
        try {
            $this->_db = new PDO('mysql:host=localhost;dbname=site;charset=utf8', 'root', '');
            $this->_db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			$this->_db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);
        }
		catch (PDOException $e) {
		    die('Erreur de connexion à la base de données : '.$e->getMessage());
        }
    }

	# Pattern Singleton
    public static function getInstance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new Db();
        }
        return self::$instance;
    }

	public function select_users($keyword='') {
		# Définition du query
		if ($keyword != '') {
			$keyword = str_replace("'", "\'", $keyword);
			$keyword = str_replace("%", "\%", $keyword);
			$query = "SELECT * FROM users WHERE name LIKE '%" . $keyword . "%' collate utf8_bin ORDER BY no ASC ";
		} else {
			$query = 'SELECT * FROM users ORDER BY name ASC';
		}
		$result = $this->_db->query($query);

		# Parcours de l'ensemble des résultats et construction d'un tableau d'objet(s) de la classe Livre
		$tableau = array();
		if ($result->rowcount()!=0) {
			while ($row = $result->fetch()) {
				$tableau[] = new User($row->num_user,$row->name,$row->firstname,$row->adress, $row->email, $row->password, $row->iban, $row->role, $row->phone);
			}
		}
		return $tableau;
	}
	
	public function select_users_valid() {
		
			$query = 'SELECT * FROM users WHERE valid=0 ORDER BY name ASC';
			
		$result = $this->_db->query($query);

		# Parcours de l'ensemble des résultats et construction d'un tableau d'objet(s) de la classe Livre
		$tableau = array();
		if ($result->rowcount()!=0) {
			while ($row = $result->fetch()) {
				$tableau[] = new User($row->num_user,$row->name,$row->firstname,$row->adress,$row->email,$row->password,$row->phone,$row->iban,$row->role,$row->responsible_role,$row->valid);
			}
		}
		return $tableau;
	}
	public function select_users_responsable() {
		
			$query = 'SELECT * FROM users WHERE role = "responsible" OR role = "trainer" ORDER BY name ASC';
			
		$result = $this->_db->query($query);

		# Parcours de l'ensemble des résultats et construction d'un tableau d'objet(s) de la classe Livre
		$tableau = array();
		if ($result->rowcount()!=0) {
			while ($row = $result->fetch()) {
				$tableau[] = new User($row->num_user,$row->name,$row->firstname,$row->adress, $row->email, $row->password, $row->iban, $row->role_responsable, $row->phone);
			}
		}
		return $tableau;
	}
	
	public function insert_user($name, $firstname, $adress, $email, $password, $iban) {
		$query = 'INSERT INTO users (name, firstname, adress, email, password, iban)
				  values (:name, :firstname, :adress, :email, :password, :iban )';
		$qp = $this->_db->prepare($query);

	$qp->bindValue(':name',$name);
    $qp->bindValue(':firstname',$firstname);
    $qp->bindValue(':adress',$adress);
    $qp->bindValue(':email',$email);
    $qp->bindValue(':password',$password);
    $qp->bindValue(':iban',$iban);
    		$qp->execute();

	}
	public function valid_user($no){
		$query = "UPDATE users set valid=1 WHERE num_user=:no ";
		$qp = $this->_db->prepare($query);
		
		$qp->bindValue(':no',$no);
		$qp->execute();
	}

	public function select_events($keyword='') {
		if ($keyword != '') {
			$keyword = str_replace("%", "\%", $keyword);
			$keyword = str_replace("%','%", $keyword);
			$query = "SELECT * FROM events WHERE name LIKE '%" . $keyword . "%' collate utf8_bin ORDER BY no ASC ";	
		} else {
			$query = 'SELECT * FROM events ORDER BY date DESC';
		}
		$result = $this->_db->query($query);
		$tableau = array();
		if ($result->rowcount()!=0){
			while ($row = $result->fetch()) {		
			$tableau[] = new Event($row->num_event,$row->name,$row->date,$row->photo,$row->description,$row->num_likes,$row->num_participants,$row->num_interests);
		    }
		}
		return $tableau;
	}	
	
	public function insert_event($num_event,$name,$date,$photo,$description) {
		# Solution d'INSERT avec prepared statement
		$query = 'INSERT INTO events (num_event, name, date, photo, description) values (:num_event,:name,:date,:photo,:description)';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_event',$num_event);
		$ps->bindValue(':name',$name);
		$ps->bindValue(':date',$date);
		$ps->bindValue(':photo',$photo);
		$ps->bindValue(':description',$description);
		return $ps->execute();
	}
	
	public function delete_event($num_event) {
		# Solution de DELETE avec prepared statement
		$query = 'DELETE FROM events WHERE num_event=:num_event LIMIT 1';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_event',$num_event);
		return $ps->execute();
	}
	
	public function select_event($num_event) {
		$query = 'SELECT * FROM events WHERE num_event=:num_event';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_event',$num_event);
		$ps->execute();
		$row = $ps->fetch();	
		return new Event($row->num_event,$row->name,$row->date,$row->photo,$row->description,$row->num_likes,$row->num_participants,$row->num_interests);
	}	
	
	public function update_event($num_event,$name,$date,$photo,$description,$num_likes,$num_participants,$num_interests) {
		$query = 'UPDATE events SET name=:name,date=:date,photo=:photo,description=:description,num_likes=:num_likes,num_participants=:num_participants,num_interests=:num_interests WHERE num_event=:num_event';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_event',$num_event);
		$ps->bindValue(':name',$name);
		$ps->bindValue(':date',$date);
		$ps->bindValue(':photo',$photo);
		$ps->bindValue(':description',$description);
		$ps->bindValue(':num_likes',$num_likes);
		$ps->bindValue(':num_participants',$num_participants);
		$ps->bindValue(':num_interests',$num_interests);
		return $ps->execute();
	}
	
	public function select_trainings($keyword='') {
		if ($keyword != '') {
			$keyword = str_replace("%", "\%", $keyword);
			$keyword = str_replace("%','%", $keyword);
			$query = "SELECT * FROM users_trainings WHERE name LIKE '%" . $keyword . "%' collate utf8_bin ORDER BY no ASC ";	
		} else {
			$query = 'SELECT * FROM users_trainings ORDER BY date DESC';
		}
		$result = $this->_db->query($query);
		$tableau = array();
		if ($result->rowcount()!=0){
			while ($row = $result->fetch()) {		
			$tableau[] = new User_training ($row->num_plan,$row->num_user,$row->date);
		    }
		}
		return $tableau;
	}	
	
	public function insert_training($num_training,$num_plan,$nom,$num_user) {
		# Solution d'INSERT avec prepared statement
		$query = 'INSERT INTO training (num_training, num_plan, nom, num_user) values (:num_training,:nun_plan,:nom,:num_user)';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_training',$num_training);
		$ps->bindValue(':num_plan',$num_plan);
		$ps->bindValue(':nom',$nom);
		$ps->bindValue(':num_user',$num_user);
		return $ps->execute();
	}
	
	public function delete_training($num_training){
		$query = 'DELETE FROM training WHERE num_training=:num_training LIMIT 1';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_traing',$num_training);
		return $ps->execute();
	}
	
	public function select_training($num_training) {
		$query = 'SELECT * FROM training WHERE num_training=:num_training';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_training',$num_training);
		$ps->execute();
		$row = $ps->fetch();	
		return new Training($row->num_training,$row->num_plan,$row->nom,$row->num_user);
	}
	
	public function update_training($num_training,$num_plan,$nom,$num_user) {
		$query = 'UPDATE training SET num_plan=:num_plan,nom=:nom,num_user=:num_user WHERE num_training=:num_training';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_training',$num_training);
		$ps->bindValue(':num_plan',$num_plan);
		$ps->bindValue(':nom',$nom);
		$ps->bindValue(':num_user',$num_user);
		return $ps->execute();
	}
	
	public function select_plans($keyword='') {
		if ($keyword != '') {
			$keyword = str_replace("%", "\%", $keyword);
			$keyword = str_replace("%','%", $keyword);
			$query = "SELECT * FROM training_plans WHERE name LIKE '%" . $keyword . "%' collate utf8_bin ORDER BY no ASC ";	
		} else {
			$query = 'SELECT * FROM training_plans ORDER BY date DESC';
		}
		$result = $this->_db->query($query);
		$tableau = array();
		if ($result->rowcount()!=0){
			while ($row = $result->fetch()) {		
			$tableau[] = new Training_plan($row->num_plan,$row->nom,$row->num_user,$row->num_training);
		    }
		}
		return $tableau;
	}	
	
	public function insert_plan($num_training,$title,$date) {
		$query = 'INSERT INTO plan (num_training, title, date) values (:num_training,:title,:date)';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_training',$num_training);
		$ps->bindValue(':title',$title);
		$ps->bindValue(':date',$date);
		return $ps->execute();
	}
	
	public function delete_plan($num_plan){
		$query = 'DELETE FROM training WHERE num_training=:num_training LIMIT 1';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':num_traing',$num_training);
		return $ps->execute();
	}
	
	public function update_user($email,$name,$firstname,$adress,$password,$phone,$iban,$responsible_role){
	    $query = 'UPDATE users SET name=:name,firstname=:firstname,adress=:adress,password=:password,phone=:phone,iban=:iban,responsible_role=:responsible_role WHERE email=:email';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':email',$email);
		$ps->bindValue(':name',$name);
		$ps->bindValue(':firstname',$firstname);
		$ps->bindValue(':adress',$adress);
		$ps->bindValue(':password',$password);
		$ps->bindValue(':phone',$phone);
		$ps->bindValue(':iban',$iban);
		$ps->bindValue(':responsible_role',$responsible_role);
		return $ps->execute();
	}
	
	public function select_user($email) {
		$query = 'SELECT * FROM users WHERE email=:email';
		$ps = $this->_db->prepare($query);
		$ps->bindValue(':email',$email);
		$ps->execute();
		$row = $ps->fetch();
        if ($ps->rowcount()!=0){
		$tableau=new User($row->num_user,$row->name,$row->firstname,$row->adress,$row->email,$row->password,$row->phone,$row->iban,$row->role,$row->responsible_role,$row->valid);
		} else { 
		
		$tableau = new User('Unknown', 'unknown','','','','','','','','','');
		}
		return $tableau;
	}
}
