<?php
class User{
  private $_num_user;
  private $_name;
  private $_firstname;
  private $_adress;
  private $_email;
  private $_password;
  private $_phone;
  private $_iban;
  private $_role;
  private $_responsible_role;
  private $valid;

  public function __construct($num_user, $name, $firstname, $adress, $email, $password, $phone, $iban, $role, $responsible_role, $valid){
  $this->_num_user = $num_user;
    $this->_name = $name;
    $this->_firstname = $firstname;
    $this->_adress = $adress;
    $this->_email = $email;
    $this->_password = $password;
  $this->_phone = $phone;
    $this->_iban = $iban;
    $this->_role = $role;
  $this->_responsible_role = $responsible_role;
  $this->_valid = $valid;
  }

  public function num_user(){
     return $this->_num_user;
  }

  public function name(){
    return $this->_name;
  }

  public function firstname(){
    return $this->_firstname;
  }
  
  public function adress(){
    return $this->_adress;
  }
  
  public function email(){
    return $this->_email;
  }
  
  public function password(){
    return $this->_password;
  }
  
  public function phone(){
    return $this->_phone;
  }
  
  public function iban(){
    return $this->_iban;
  }
  
  public function role(){
    return $this->_role;
  }
  
  public function responsible_role(){
    return $this->_responsible_role;
  }
  
  public function valid(){
    return $this->_valid;
  }
  
  
  public function html_no(){
    return htmlspecialchars($this->_num_user); 
  } 
    
  public function html_name(){
    return htmlspecialchars($this->_name);
  }
  
  public function html_firstname(){
    return htmlspecialchars($this->_firstname);
  }
  
  public function html_adress(){
    return htmlspecialchars($this->_adress);
  }
  public function html_email(){
    return htmlspecialchars($this->_email);
  }
  public function html_phone(){
    return htmlspecialchars($this->_phone);
  }
}
?>