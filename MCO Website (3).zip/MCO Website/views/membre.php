<section id="contenu">
 <div class="row">
                <div class="col col_6_of_12">
<h2>Bienvenue sur la page de votre profil </h2>
  </br><strong>Prénom : </strong><td><?php echo $user->firstname() ?></td>
  </br></br><strong>Nom :</strong><td><?php echo $user->name() ?></td>
  </br></br><strong>Adresse :</strong><td><?php echo $user->adress() ?></td>
  </br></br><strong>Email : </strong><td><?php echo $user->email() ?></td>
  </br></br><strong>Téléphone :</strong><td><?php echo $user->phone() ?></td>
  </br></br>Votre fonction est <strong><?php echo $user->responsible_role() ?> </strong>.
  <p>
  </br>
  </br>
  </br>
  </br>
  </br>
  </br>
  </p>
  <p></br>Vous souhaitez modifier votre profil ? 
   
    <a href="index.php?action=modification"><input type="button" name="Modifier" value="Modifier mon profil" ></button></p></a>
</div>
		<div class="col col_6_of_12">
         		 <!-- row 6 of 12 -->
				 
				 <h2> Evènements à venir </h2>
				 
	<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Nom</th>
      <th scope="col">Date</th>
      <th scope="col">Photo</th>
      <th scope="col">Description</th>
	  <th scope="col">Likes</th>
	  <th scope="col">Participants</th>
	  <th scope="col">Interressés</th>
    </tr>
  </thead>
  <tbody>
  
  <?php for ($i=0;$i<count($tab_events);$i++) { ?>
      <tr>
      
      <td><?php echo $tab_events[$i]->name() ?></td>
      <td><?php echo $tab_events[$i]->date() ?></td>
      <td><?php echo $tab_events[$i]->photo() ?></td>
      <td><?php echo $tab_events[$i]->description() ?></td>
      <td><?php echo $tab_events[$i]->num_likes() ?></td>
      <td><?php echo $tab_events[$i]->num_participants() ?></td>
      <td><?php echo $tab_events[$i]->num_interests() ?></td>

      </tr>
    <?php } ?>
  
  
 
</table>

			 
				 
	
  </div>
            </div> 
            <div id="notification"><?php echo $notification; ?></div>
      <form action="?action=valider" method="post">

<table class="tableBalises">
        <thead>
          <tr>
            <th>name</th>
            <th>firstname</th>
            <th>email</th>
            <th>phone</th>
            <th>adress</th>
            <th>Valider</th>
          </tr>
        </thead>
          <tbody>
          <?php for ($i=0;$i<count($tab_users);$i++) { ?>
            <tr>
              <td><span class="html"><?php echo $tab_users[$i]->html_name() ?></span></td>
              <td><?php echo $tab_users[$i]->html_firstname() ?></td>
              <td><?php echo $tab_users[$i]->html_email() ?></td>
              <td><?php echo $tab_users[$i]->html_phone() ?></td>
              <td><?php echo $tab_users[$i]->html_adress() ?></td>
              <td><input type="radio" name="invalid_user" value="<?php echo $tab_users[$i]->html_no() ?>"> </td>
            </tr>
          <?php } ?>
          
        </tbody>
        </table>
        <p><input type="submit" value="Submit"></p>
		  
</section>
