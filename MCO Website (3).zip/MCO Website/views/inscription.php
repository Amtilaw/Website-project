<body>
<div id="notification"><?php echo $notification; ?></div>
			<div class="formulaire">
				
<form action="?action=inscription" method="post">
    <p class="h4 text-center mb-4">Subscribe</p>

    <!-- Material input text -->
    <div class="md-form" >
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="name" placeholder="name*">
        <label for="materialFormSubscriptionNameEx" ></label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="firstname" placeholder="Firstname*">
        <label for="materialFormSubscriptionNameEx"></label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="phone" placeholder="phone*">
        <label for="materialFormSubscriptionNameEx"></label>
    </div>

    <!-- Material input email -->
    <div class="md-form">
        <i class="fa fa-envelope prefix grey-text"></i>
        <input type="email" id="materialFormSubscriptionEmailEx" class="form-control" name="email" placeholder="email*">
        <label for="materialFormSubscriptionEmailEx"></label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="adress" placeholder="adress*">
        <label for="materialFormSubscriptionNameEx" ></label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="iban" placeholder="Iban*">
        <label for="materialFormSubscriptionNameEx"></label>
    </div>

    <div class="md-form">
        <i class="fa fa-user prefix grey-text"></i>
        <input type="text" id="materialFormSubscriptionNameEx" class="form-control" name="photo" placeholder="photo">
        <label for="materialFormSubscriptionNameEx"></label>
    </div>

    <div class="md-form">
                <i class="fa fa-lock prefix grey-text"></i>
                <input type="password" id="materialFormCardPasswordEx" class="form-control" name="password" placeholder="password*">
                <label for="materialFormCardPasswordEx" class="font-weight-light"></label>
            </div>
    <div class="text-center mt-4">
        <button class="btn btn-outline-info" type="submit">Send<i class="fa fa-paper-plane-o ml-2"></i></button>
    </div>
</form>
<!-- Material form subscription -->
                      
			</div>


</body>