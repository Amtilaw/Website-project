<body>

<div id="notification"><?php echo $notification; ?></div>
			<form action="?action=membreResponsable" method="post">

<table class="tableBalises">
				   <caption>Liste des responsables</caption>

				<thead>
					<tr>
						<th>name</th>
						<th>firstname</th>
						<th>email</th>
						<th>role</th>
						
					</tr>
				</thead>
					<tbody>
					<?php for ($i=0;$i<count($tab_users);$i++) { ?>
						<tr>
							<td><span class="html"><?php echo $tab_users[$i]->html_name() ?></span></td>
							<td><?php echo $tab_users[$i]->html_firstname() ?></td>
							<td><?php echo $tab_users[$i]->html_email() ?></td>
							<td><?php echo $tab_users[$i]->html_role() ?></td>
							<td><select name="responsabilities">
							<option value="tresorier">tresorier</option>
							<option value="trainer">trainer</option>
							<option value="president">president</option>
							<option value="admin">admin</option>
							</select></td>
							<td><input type="submit" value="valider"></td>
						</tr>
					<?php } ?>
					
				</tbody>
				</table>
				
<a href="index.php?action=valider"><button type="button" class="btn btn-success btn-rounded" name="valider">Validate users</button></a>
</body>