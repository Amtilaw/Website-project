<body>
<div id="notification"><?php echo $notification; ?></div>
			<form action="?action=cotisation" method="post">

<table class="tableBalises">
				<thead>
					<tr>
						<th>name</th>
						<th>firstname</th>
						<th>montant</th>
						</tr>
				</thead>
					<tbody>
					<?php for ($i=0;$i<count($tab_users);$i++) { ?>
						<tr>
							<td><span class="html"><?php echo $tab_users[$i]->html_name() ?></span></td>
							<td><?php echo $tab_users[$i]->html_firstname() ?></td>
							<td><?php echo 5?></td>
							<td><button>payer</button></td>
							
					<?php } ?>
				</tbody>
				</table>
</body>