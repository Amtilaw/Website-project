<body>

<div id="notification"><?php echo $notification; ?></div>
			<form action="?action=valider" method="post">

<table class="tableBalises">
				<thead>
					<tr>
						<th>name</th>
						<th>firstname</th>
						<th>email</th>
						<th>phone</th>
						<th>adress</th>
						<th>Valider</th>
					</tr>
				</thead>
					<tbody>
					<?php for ($i=0;$i<count($tab_users);$i++) { ?>
						<tr>
							<td><span class="html"><?php echo $tab_users[$i]->html_name() ?></span></td>
							<td><?php echo $tab_users[$i]->html_firstname() ?></td>
							<td><?php echo $tab_users[$i]->html_email() ?></td>
							<td><?php echo $tab_users[$i]->html_phone() ?></td>
							<td><?php echo $tab_users[$i]->html_adress() ?></td>
							<td><input type="radio" name="invalid_user" value="<?php echo $tab_users[$i]->html_no() ?>"> </td>
						</tr>
					<?php } ?>
					
				</tbody>
				</table>
				<p><input type="submit" value="Submit"></p>






</body>