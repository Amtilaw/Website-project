		<section id="contenu">
		 <div class="row">
                <div class="col col_6_of_12">
                    <!--colonne 6 sur 12-->
					</br>
			<h2>Connexion vers la zone membre</h2>
	
			
			<div class="formulaire">
				<form action="?action=login" method="post">
				<p>Email : <input type="text" name="email" /></p>
				<p>Mot de passe : <input type="password" name="password" /></p>
				<p><button type="submit" class="btn btn-primary">Connexion</button></p>
				</form>
				</div>
				</div>
				
				 <div class="col col_6_of_12">
				 </br>
				 <p align="center">Vous ne possédez pas encore de compte membre ? </br> Inscrivez-vous ici : 
				 <a href="index.php?action=inscription"> <button type="button" class="btn btn-primary">Inscription</button> </a>
				 </p>
				 
				 </div>
				 
			</div>
		</section>
