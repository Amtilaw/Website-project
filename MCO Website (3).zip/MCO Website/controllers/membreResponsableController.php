<?php
class membreResponsableController{
private $_db;
	public function __construct($db) {
	$this->_db = $db;
	}

	public function run(){

	
	$notification = '';
	$tab_users = '';
	
	
	if (!empty($_POST)){
		
			if (!empty($_POST['responsabilities'])){
				$tab_users=$this->_db->update_users_responsable($_POST['responsabilities']);
				$notification = 'Users have been update';
			}
		
	}
			$tab_users=$this->_db->select_users_responsable();
		# Un contr�leur se termine en �crivant une vue
		require_once(CHEMIN_VUES . 'membreResponsable.php');
	}
}
?>
