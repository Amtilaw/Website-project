<?php
class CotisationController{
private $_db;
	public function __construct($db) {
	$this->_db = $db;
	}

	public function run(){

	$notification = '';
	$tab_users = '';
	if (!empty($_POST)){
		
					$this->_db->valid_user($_POST['invalid_user'] ,$tab_users[$i]->html_no());
	}
			$tab_users=$this->_db->select_users_cotisation();
		# Un contr�leur se termine en �crivant une vue
		require_once(CHEMIN_VUES . 'cotisation.php');
	}
}
?>
