<?php
class AccueilController{

	public function __construct() {

	}

	public function run(){

		#test des deux boutons register et login_admin
	 

		# Un contrôleur se termine en écrivant une vue
		require_once(CHEMIN_VUES . 'accueil.php');
	}

}
?>
