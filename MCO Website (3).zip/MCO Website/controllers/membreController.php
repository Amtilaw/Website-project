	<?php
class MembreController{
	
	private $_db;
	public function __construct($db) {
		$this->_db = $db;
	}

	public function run(){
		
		
		$tab_users = '';
	
	
	if (!empty($_POST)){
		
					$this->_db->valid_user($_POST['invalid_user']);
				
				$notification = 'User(s) had been update';
		
	}
	else {
				$notification = 'no user valid';
			}

			$tab_users=$this->_db->select_users_valid();
			$user=$this->_db->select_user($_SESSION['login']);
		
		if (isset($_SESSION['authentifie']) AND isset($_SESSION['login'])){
			echo 'Bonjour ' . $user->firstname() . ' ! ';
        }
		
		$notification = '';
		$tab_events = '';
		
		
		$tab_events=$this->_db->select_events();
		
		
	

		require_once(CHEMIN_VUES . 'membre.php');
		
	}
}
?>
