<?php 
class LoginController{

	private $_db;
	public function __construct($db) {
		$this->_db = $db;
	}
		
	public function run(){	
		if (!empty($_SESSION['authentifie'])) {
			header("Location: index.php?action=membre"); 
			die(); 
		}	
	
	
		$notification='';
	
		
        if (!empty($_POST)) {
			$test2=$_POST['email'];
		$test=$this->_db->select_user($test2);}

		if (empty($_POST)) {
			$notification='Authentifiez-vous';
		} elseif (($_POST['email']!=$test->email() || $_POST['password']!=$test->password())) {
			echo $notification='Vos données d\'authentification ne sont pas correctes.';
		} else {
			$_SESSION['authentifie'] = 'autorise'; 
			$_SESSION['login'] = $_POST['email'];
			header("Location: index.php?action=membre"); 
			die();
		}
		

		require_once(CHEMIN_VUES . 'login.php');
	}
	
} 
?>

