<?php
class ValiderController{
private $_db;
	public function __construct($db) {
	$this->_db = $db;
	}

	public function run(){

	
	$notification = '';
	$tab_users = '';
	
	
	if (!empty($_POST)){
		
					$this->_db->valid_user($_POST['invalid_user']);
				
				$notification = 'User(s) had been update';
		
	}
	else {
				$notification = 'no user valid';
			}
			$tab_users=$this->_db->select_users_valid();
		# Un contr�leur se termine en �crivant une vue
		require_once(CHEMIN_VUES . 'valider.php');
	}
}
?>
