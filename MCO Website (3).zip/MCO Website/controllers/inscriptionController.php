<?php
class InscriptionController{

	private $_db;
	public function __construct($db) {
		$this->_db = $db;
	}

	public function run(){

		$notification = '';
		$valide = true;

		#Checking 
		if (empty($_POST)) {
			$notification = 'complete the form';
			$valide = false;
		}
		else if (empty($_POST['name'])){
			$notification = 'complete the name';
			$valide = false;
		}
		else if (empty($_POST['firstname'])){
			$notification = 'complete the firstname';
			$valide = false;
		}
		else if (empty($_POST['phone'])){
			$notification = 'complete the phone';
			$valide = false;
		}
		else if (empty($_POST['email'])){
			$notification = 'complete the email';
			$valide = false;
		}
		else if (empty($_POST['adress'])){
			$notification = 'complete the adress';
			$valide = false;
		}
		else if (empty($_POST['iban'])){
			$notification = 'complete the iban';
			$valide = false;
		}
		else if (empty($_POST['password'])){
			$notification = 'complete the password';
			$valide = false;
		}
		else if(!(empty($_POST['email']))) {
			//Verify the syntaxe of the email adress
		if(!(preg_match('#^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,6}$#', $_POST['email']))) {
			$notification = 'Email adress not valide';
			$valide = false;
			}
		}
		else if(!(empty($_POST['iban']))) {
			//Verify the syntaxe of the email adress
		if(!(preg_match('#^BE[0-9]{9}#', $_POST['iban']))) {
			$notification = 'IBAN not valide';
			$valide = false;
			}
		}

		if ($valide){
				if ($this->_db->insert_user($_POST['name'],$_POST['firstname'],$_POST['phone'],$_POST['email'],$_POST['adress'],$_POST['iban'],$_POST['password']))
				{
					$notification='Ajout bien fait';
				} else {
					$_SESSION['authentifie'] = 'sucess'; 
					$_SESSION['name'] = $_POST['name'];
					$_SESSION['firstname'] = $_POST['firstname'];

					header("Location: index.php?action=AccueilUser"); 
					die();
				}	
			}
		
		
		# Un contrôleur se termine en écrivant une vue
		require_once(CHEMIN_VUES . 'inscription.php');
	}

}
?>
